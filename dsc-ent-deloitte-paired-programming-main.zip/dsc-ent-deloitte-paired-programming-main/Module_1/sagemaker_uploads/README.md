# Quick Start

If you already know how to create a SageMaker notebook instance and feel comfortable uploading files with the SageMaker JupyterLab interface, then you can use the contents of this folder to quickly create this model AB testing endpoint; simply upload the `AB Testing Workflow` notebook (along with the `model` and `test_data` folders and their contents) and run all cells after completing the required [Configuration steps](https://github.com/flatiron-school/DS-Deloitte-07062022-AB-Testing-ML-Models-on-AWS/#Configuration).
